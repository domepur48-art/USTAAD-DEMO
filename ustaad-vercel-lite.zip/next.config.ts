import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The managed preview proxy connects to the dev server from this host.
  allowedDevOrigins: ["127.0.0.1"],
};

export default nextConfig;
