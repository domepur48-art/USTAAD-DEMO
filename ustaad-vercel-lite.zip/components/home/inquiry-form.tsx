"use client";

import { MessageCircle, Send } from "lucide-react";
import { FormEvent, useState } from "react";
import { siteData } from "@/data/site";

type InquiryType = "restaurant" | "banquet";

const copy = {
  restaurant: { eyebrow: "RESTAURANT INQUIRY", title: "Plan your table.", description: "Tell us when you would like to visit and the owner can confirm availability." },
  banquet: { eyebrow: "BANQUET INQUIRY", title: "Start your occasion.", description: "Share the first details for your event in Ustaad’s single banquet hall." },
} as const;

export function InquiryForm({ type }: { type: InquiryType }) {
  const [sent, setSent] = useState(false);
  const content = copy[type];

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const fields = Array.from(form.entries()).map(([key, value]) => `${key}: ${String(value)}`).join("\n");
    const message = `Hello Ustaad, I have a ${type} inquiry.\n\n${fields}`;
    window.open(`${siteData.whatsappHref}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
    setSent(true);
  }

  return (
    <section className={`inquiry-card inquiry-card--${type}`} id={type === "restaurant" ? "restaurant-inquiry" : "banquet-inquiry"} aria-labelledby={`${type}-inquiry-title`}>
      <div className="inquiry-card__intro">
        <p className="eyebrow">{content.eyebrow}</p>
        <h2 id={`${type}-inquiry-title`}>{content.title}</h2>
        <p>{content.description}</p>
        <span className="inquiry-card__direct"><MessageCircle size={15} aria-hidden="true" /> Opens a WhatsApp message to the owner</span>
      </div>
      <form className="inquiry-form" onSubmit={submit}>
        <label><span>Your name</span><input name="name" required autoComplete="name" placeholder="Name" /></label>
        <label><span>Phone number</span><input name="phone" required type="tel" autoComplete="tel" placeholder="+91 ..." /></label>
        <label><span>Preferred date</span><input name="date" required type="date" /></label>
        <label><span>{type === "banquet" ? "Guests" : "People"}</span><input name="guests" required type="number" min="1" max="1000" placeholder="Number" /></label>
        {type === "banquet" && <label><span>Occasion</span><select name="occasion" defaultValue=""><option value="" disabled>Select an occasion</option><option>Wedding</option><option>Engagement</option><option>Birthday / family function</option><option>Corporate function</option><option>Other</option></select></label>}
        <label className="inquiry-form__wide"><span>Note</span><textarea name="note" rows={3} placeholder={type === "banquet" ? "Tell us about your event" : "Any seating or menu note"} /></label>
        <button className="button-link button-link--gold button-link--whatsapp inquiry-form__submit" type="submit"><span className="button-link__content"><span>{sent ? "Message ready" : "Continue on WhatsApp"}</span>{sent ? <MessageCircle size={15} aria-hidden="true" /> : <Send size={15} aria-hidden="true" />}</span></button>
      </form>
    </section>
  );
}
