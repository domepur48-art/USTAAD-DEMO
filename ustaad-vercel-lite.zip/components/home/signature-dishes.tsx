import { ArrowUpRight } from "lucide-react";
import { homeContent } from "@/data/home";
import { SectionHeading } from "@/components/ui/section-heading";
import { ImageReveal } from "@/components/ui/reveal";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

export function SignatureDishes() {
  return (
    <section className="section-space signature-section" id="food">
      <div className="page-shell">
        <div className="signature-section__heading">
          <SectionHeading eyebrow={homeContent.signatureEyebrow} title={homeContent.signatureTitle} description="A few favourites to start the conversation. Menu details and prices are being confirmed." />
          <span className="signature-section__index">01 <i>—</i> 04</span>
        </div>
        <div className="dish-grid">
          {homeContent.dishes.map((dish, index) => (
            <article className={`dish-card dish-card--${index + 1}`} key={dish.name}>
                <ImageReveal className={`dish-card__image dish-card__image--${dish.photoId}`} delay={index * 0.06}>
                <PhotoPlaceholder variant={index % 2 === 0 ? "kitchen" : "arch"} label={`${dish.name} at Ustaad`} />
                <span className="dish-card__number">0{index + 1}</span>
              </ImageReveal>
              <div className="dish-card__content">
                <div><p className="dish-card__category">{dish.category}</p><h3>{dish.name}</h3></div>
                <span className="dish-card__price">{dish.price}</span>
              </div>
              <span className="dish-card__arrow" aria-hidden="true"><ArrowUpRight size={18} /></span>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
