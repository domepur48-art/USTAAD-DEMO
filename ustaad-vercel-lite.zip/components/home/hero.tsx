"use client";

import { ArrowDown, ArrowUpRight, MapPin, Sparkles, Utensils } from "lucide-react";
import Link from "next/link";
import { useEffect } from "react";
import { homeContent } from "@/data/home";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

export function HomeHero() {
  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      const panels = [...document.querySelectorAll<HTMLElement>(".home-hero__split-panel")];
      const activePanel = panels.find((panel) => {
        const bounds = panel.getBoundingClientRect();
        return event.clientX >= bounds.left && event.clientX <= bounds.right && event.clientY >= bounds.top && event.clientY <= bounds.bottom;
      });
      panels.forEach((panel) => {
        if (panel !== activePanel) {
          panel.style.setProperty("--hero-cursor-x", "0px");
          panel.style.setProperty("--hero-cursor-y", "0px");
        }
      });
      if (!activePanel) return;
      const bounds = activePanel.getBoundingClientRect();
      const x = ((event.clientX - bounds.left) / bounds.width - 0.5) * 70;
      const y = ((event.clientY - bounds.top) / bounds.height - 0.5) * 45;
      activePanel.style.setProperty("--hero-cursor-x", `${x.toFixed(2)}px`);
      activePanel.style.setProperty("--hero-cursor-y", `${y.toFixed(2)}px`);
    };
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section id="home-hero" className="home-hero home-hero--split">
      <div className="home-hero__split-stage">
        <article className="home-hero__split-panel home-hero__split-panel--restaurant">
          <PhotoPlaceholder variant="ambience" label="Ustaad restaurant photo needed" />
          <div className="home-hero__split-overlay" />
          <div className="home-hero__split-content">
            <span className="home-hero__panel-index">01 <i /> THE RESTAURANT</span>
            <Utensils size={24} aria-hidden="true" />
            <p className="eyebrow">WEAVERS COLONY · KUSHAIGUDA</p>
            <h1>Come for<br /><em>the table.</em></h1>
            <p className="home-hero__split-description">Biryani, kebabs, Indian favourites, Chinese, seafood and vegetarian dishes, served for everyday meals and shared occasions.</p>
            <a className="home-hero__split-cta" href="/restaurant">Explore the restaurant <ArrowUpRight size={15} aria-hidden="true" /></a>
          </div>
        </article>

        <article className="home-hero__split-panel home-hero__split-panel--hall">
          <PhotoPlaceholder variant="banquet" label="Ustaad single banquet hall photo needed" />
          <div className="home-hero__split-overlay" />
          <div className="home-hero__split-content">
            <span className="home-hero__panel-index">02 <i /> THE SINGLE HALL</span>
            <Sparkles size={24} aria-hidden="true" />
            <p className="eyebrow">USTAAD BANQUETS · KUSHAIGUDA</p>
            <h1>Make it<br /><em>a moment.</em></h1>
            <p className="home-hero__split-description">One considered hall for weddings, engagements, birthdays, corporate and family functions, planned directly with the owner.</p>
            <Link className="home-hero__split-cta" href="/banquets-events">Explore the banquet hall <ArrowUpRight size={15} aria-hidden="true" /></Link>
          </div>
        </article>

        <a className="home-hero__scroll" href="/restaurant" aria-label="Open the Restaurant page"><ArrowDown size={15} aria-hidden="true" /></a>
      </div>
      <div className="home-hero__split-bottom page-shell"><span><MapPin size={13} aria-hidden="true" /> {homeContent.hero.eyebrow}</span><span>RESTAURANT · ONE HALL · KUSHAIGUDA</span></div>
    </section>
  );
}
