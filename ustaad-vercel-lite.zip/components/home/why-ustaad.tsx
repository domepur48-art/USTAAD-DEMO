import { Utensils, Soup, Fish, Building2 } from "lucide-react";
import { homeContent } from "@/data/home";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";

const icons = [Utensils, Soup, Fish, Building2];

export function WhyUstaad() {
  return (
    <section className="section-space why-section">
      <div className="page-shell why-layout">
        <Reveal className="why-section__intro">
          <SectionHeading eyebrow="ONE ADDRESS, MANY REASONS" title="A little of everything. All under one roof." description="A restaurant for everyday meals, and a banquet hall for the days you plan ahead." />
          <span className="why-section__ornament" aria-hidden="true">✦ <i /> ✦</span>
        </Reveal>
        <div className="why-list">
          {homeContent.whyUs.map((item, index) => {
            const Icon = icons[index];
            return (
              <Reveal className="why-item" key={item.title} delay={index * 0.055}>
                <span className="why-item__number">0{index + 1}</span>
                <span className="why-item__icon"><Icon size={20} strokeWidth={1.5} aria-hidden="true" /></span>
                <div><h3>{item.title}</h3><p>{item.description}</p></div>
                <span className="why-item__rule" aria-hidden="true" />
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
