"use client";

import { CalendarDays, ChevronRight, Users } from "lucide-react";
import { useMemo, useState } from "react";

const packages = ["Classic", "Premium", "Signature"] as const;
type PackageName = (typeof packages)[number];

export function EventPlanner() {
  const [guests, setGuests] = useState(120);
  const [packageName, setPackageName] = useState<PackageName>("Premium");
  const progress = ((guests - 20) / 280) * 100;
  const note = useMemo(() => {
    if (guests < 80) return "An intimate gathering in the single hall.";
    if (guests < 180) return "A comfortable celebration for your people.";
    return "A full-house occasion at Ustaad.";
  }, [guests]);

  return (
    <section className="event-planner section-space" id="plan-event" aria-labelledby="event-planner-title">
      <div className="page-shell event-planner__layout">
        <div className="event-planner__intro">
          <p className="eyebrow">PLAN YOUR OCCASION</p>
          <h2 id="event-planner-title">One hall.<br /><em>Many ways to gather.</em></h2>
          <p>Move the slider to shape your first enquiry. Ustaad has one single banquet hall; the owner will confirm capacity, availability and pricing with you.</p>
          <a className="text-link" href="#banquet-inquiry">Continue to an inquiry <ChevronRight size={15} aria-hidden="true" /></a>
        </div>
        <div className="event-planner__tool">
          <div className="event-planner__tool-head"><span><Users size={17} aria-hidden="true" /> How many guests?</span><strong>{guests} <small>guests</small></strong></div>
          <div className="event-planner__range-wrap">
            <input aria-label="Number of guests" type="range" min="20" max="300" step="10" value={guests} onChange={(event) => setGuests(Number(event.target.value))} style={{ "--range-progress": `${progress}%` } as React.CSSProperties} />
            <div className="event-planner__range-labels"><span>20</span><span>300+</span></div>
          </div>
          <div className="event-planner__hall-card">
            <div className="event-planner__hall-top"><span className="event-planner__hall-number">01</span><span className="event-planner__hall-status">SINGLE HALL · USTAAD</span></div>
            <h3>Ustaad Banquet Hall</h3>
            <p>{note}</p>
            <div className="event-planner__bar" aria-hidden="true"><span style={{ width: `${progress}%` }} /></div>
            <div className="event-planner__hall-foot"><span>Owner confirms capacity</span><span>{Math.round(progress)}% planning guide</span></div>
          </div>
          <div className="event-planner__packages"><span className="event-planner__label">Choose a food conversation</span><div role="tablist" aria-label="Food package preference">{packages.map((item) => <button key={item} type="button" role="tab" aria-selected={packageName === item} className={packageName === item ? "is-active" : ""} onClick={() => setPackageName(item)}>{item}</button>)}</div></div>
          <div className="event-planner__summary"><CalendarDays size={18} aria-hidden="true" /><p>For <strong>{guests} guests</strong> on a <strong>{packageName}</strong> menu, ask the owner about dates, facilities and a tailored quote.</p></div>
        </div>
      </div>
    </section>
  );
}
