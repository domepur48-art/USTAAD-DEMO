import { SectionHeading } from "@/components/ui/section-heading";
import { Reveal } from "@/components/ui/reveal";
import { ReviewsCarousel } from "@/components/reviews/reviews-carousel";
import { homeContent } from "@/data/home";

export function ReviewsSection() {
  return (
    <section className="section-space reviews-section">
      <div className="page-shell">
        <Reveal><SectionHeading eyebrow="KIND WORDS, WHEN THEY’RE READY" title={homeContent.reviewsTitle} description={homeContent.reviewsDescription} /></Reveal>
        <ReviewsCarousel />
      </div>
    </section>
  );
}
