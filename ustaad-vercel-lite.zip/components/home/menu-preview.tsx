"use client";

import { ArrowUpRight, Leaf, Flame } from "lucide-react";
import { useMemo, useState } from "react";
import Link from "next/link";
import { menu } from "@/data/menu";

const categories = ["All", ...Array.from(new Set(menu.map((item) => item.category)))];

export function MenuPreview() {
  const [activeCategory, setActiveCategory] = useState("All");
  const filteredItems = useMemo(
    () => activeCategory === "All" ? menu : menu.filter((item) => item.category === activeCategory),
    [activeCategory],
  );

  return (
    <section className="menu-preview section-space" id="menu-preview" aria-labelledby="menu-preview-title">
      <div className="page-shell">
        <div className="menu-preview__heading">
          <div>
            <p className="eyebrow">A TASTE OF THE TABLE</p>
            <h2 id="menu-preview-title">A few Ustaad favourites.</h2>
          </div>
          <p>Browse a small preview of the kitchen. Prices are marked for owner confirmation before launch.</p>
        </div>
        <div className="menu-preview__filters" role="tablist" aria-label="Menu categories">
          {categories.map((category) => (
            <button key={category} type="button" role="tab" aria-selected={activeCategory === category} className={activeCategory === category ? "is-active" : ""} onClick={() => setActiveCategory(category)}>
              {category}
            </button>
          ))}
        </div>
        <div className="menu-preview__grid">
          {filteredItems.map((item) => (
            <article className="menu-preview__item" key={item.name}>
              <div className="menu-preview__item-top"><span className="menu-preview__category">{item.category}</span><span className="menu-preview__price">{item.price}</span></div>
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <div className="menu-preview__meta">
                <span>{item.veg ? <Leaf size={13} aria-hidden="true" /> : ""}{item.veg ? "Vegetarian" : "Chef favourite"}</span>
                {item.spice > 0 && <span><Flame size={13} aria-hidden="true" /> {"hot".repeat(item.spice)}</span>}
              </div>
            </article>
          ))}
        </div>
        <Link className="text-link menu-preview__link" href="#restaurant-inquiry">Ask about today’s menu <ArrowUpRight size={15} aria-hidden="true" /></Link>
      </div>
    </section>
  );
}
