import { Clock3, MapPin, Star } from "lucide-react";
import { siteData } from "@/data/site";
import { homeContent } from "@/data/home";

export function InfoBar() {
  return (
    <section className="info-bar page-shell" aria-label="Ustaad restaurant information">
      <div className="info-bar__item"><span className="info-bar__icon"><Clock3 size={17} aria-hidden="true" /></span><div><span className="info-bar__label">OPEN EVERY DAY</span><strong>{siteData.hoursShort}</strong></div></div>
      <div className="info-bar__item"><span className="info-bar__icon"><Star size={17} aria-hidden="true" /></span><div><span className="info-bar__label">GOOGLE REVIEWS</span><strong>{homeContent.infoBar.rating}</strong></div></div>
      <div className="info-bar__item info-bar__item--address"><span className="info-bar__icon"><MapPin size={17} aria-hidden="true" /></span><div><span className="info-bar__label">FIND USTAAD</span><strong>{siteData.address}</strong></div></div>
    </section>
  );
}
