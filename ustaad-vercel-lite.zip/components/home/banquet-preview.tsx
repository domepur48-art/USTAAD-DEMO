import Link from "next/link";
import { ArrowUpRight, MessageCircle, Phone } from "lucide-react";
import { homeContent } from "@/data/home";
import { eventTypes } from "@/data/banquets";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";
import { Reveal } from "@/components/ui/reveal";

export function BanquetPreview() {
  return (
    <section className="banquet-preview-section section-space">
      <div className="banquet-preview__grid page-shell">
        <Reveal className="banquet-preview__visual-wrap">
          <div className="banquet-preview__visual"><PhotoPlaceholder variant="banquet" label="Ustaad single hall photo needed" /><span className="banquet-preview__seal">ONE HALL<br />USTAAD</span></div>
          <div className="banquet-preview__caption"><span>CELEBRATIONS AT USTAAD</span><span>HYDERABAD · INDIA</span></div>
        </Reveal>
        <div className="banquet-preview__copy">
          <p className="eyebrow">{homeContent.banquetEyebrow}</p>
          <h2>{homeContent.banquetTitle}</h2>
          <p className="banquet-preview__description">{homeContent.banquetDescription}</p>
          <ul className="event-chips" aria-label="Occasions at Ustaad Banquets">
            {eventTypes.map((event) => <li key={event.id}>{event.name}</li>)}
          </ul>
          <div className="banquet-preview__unknowns"><p>{homeContent.capacityPlaceholder}</p><p>{homeContent.facilitiesPlaceholder}</p></div>
          <div className="banquet-preview__actions">
            <a href={siteData.phoneHref} className="button-link button-link--gold"><span className="button-link__content"><span>Call the owner</span><Phone size={15} aria-hidden="true" /></span></a>
            <a href={siteData.whatsappHref} target="_blank" rel="noopener noreferrer" className="button-link button-link--outline button-link--whatsapp"><span className="button-link__content"><span>WhatsApp</span><MessageCircle size={15} aria-hidden="true" /></span></a>
            <Link href="/banquets-events" className="text-link">Discover banquets <ArrowUpRight size={15} aria-hidden="true" /></Link>
          </div>
        </div>
      </div>
    </section>
  );
}
