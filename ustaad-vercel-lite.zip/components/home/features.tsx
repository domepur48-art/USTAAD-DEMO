import { ArrowUpRight, MapPin } from "lucide-react";
import { homeContent } from "@/data/home";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";
import { ImageReveal } from "@/components/ui/reveal";

export function Features() {
  return (
    <section className="section-space feature-section">
      <div className="page-shell feature-grid feature-grid--restaurant">
        <article className="feature-card feature-card--dine">
          <div className="feature-card__copy">
            <p className="eyebrow">{homeContent.featureCards.restaurant.eyebrow}</p>
            <h2>{homeContent.featureCards.restaurant.title}</h2>
            <p>{homeContent.restaurantFeature.description}</p>
            <a className="feature-card__link" href={siteData.directionsHref} target="_blank" rel="noopener noreferrer"><MapPin size={15} aria-hidden="true" /> {homeContent.featureCards.restaurant.link} <ArrowUpRight size={15} aria-hidden="true" /></a>
          </div>
          <ImageReveal className="feature-card__visual">
            <PhotoPlaceholder variant="ambience" label="Ustaad restaurant ambience photo needed" />
            <span className="feature-card__visual-note">{homeContent.featureCards.restaurant.note}</span>
          </ImageReveal>
          <span className="feature-card__serif" aria-hidden="true">01</span>
        </article>
      </div>
    </section>
  );
}
