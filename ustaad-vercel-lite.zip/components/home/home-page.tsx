import { HomeHero } from "@/components/home/hero";

export function HomePage() {
  return (
    <main id="main-content">
      <HomeHero />
    </main>
  );
}
