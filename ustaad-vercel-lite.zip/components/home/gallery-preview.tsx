import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { homeContent } from "@/data/home";
import { GalleryGrid } from "@/components/gallery/gallery-grid";
import { SectionHeading } from "@/components/ui/section-heading";
import { Reveal } from "@/components/ui/reveal";

export function GalleryPreview() {
  return (
    <section className="section-space gallery-preview-section">
      <div className="page-shell">
        <div className="gallery-preview-section__heading">
          <SectionHeading eyebrow={homeContent.galleryEyebrow} title={homeContent.galleryTitle} description="Our photo collection is being updated with verified Ustaad images." />
          <Reveal><Link href="/gallery" className="text-link">See the full gallery <ArrowUpRight size={16} aria-hidden="true" /></Link></Reveal>
        </div>
        <GalleryGrid preview />
      </div>
    </section>
  );
}
