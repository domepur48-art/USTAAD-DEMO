import Link from "next/link";
import { ArrowDown, ArrowUpRight, MapPin, Phone } from "lucide-react";
import { homeContent } from "@/data/home";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

export function RestaurantHero() {
  return (
    <section className="restaurant-hero" aria-labelledby="restaurant-hero-title">
      <PhotoPlaceholder variant="ambience" label="Ustaad restaurant interior" />
      <div className="restaurant-hero__overlay" aria-hidden="true" />
      <div className="page-shell restaurant-hero__content">
        <div className="restaurant-hero__copy">
          <p className="restaurant-hero__index">01 <i /> USTAAD RESTAURANT</p>
          <p className="eyebrow"><MapPin size={13} aria-hidden="true" /> {homeContent.hero.eyebrow}</p>
          <h1 id="restaurant-hero-title">Come for<br /><em>the table.</em></h1>
          <p className="restaurant-hero__description">Biryani, kebabs, Indian favourites, Chinese, seafood and vegetarian dishes for everyday meals and shared occasions.</p>
          <div className="restaurant-hero__actions">
            <a className="button-link button-link--gold" href="#restaurant-content"><span className="button-link__content"><span>Explore the menu</span><ArrowDown size={15} aria-hidden="true" /></span></a>
            <a className="button-link button-link--outline" href={siteData.phoneHref}><span className="button-link__content"><span>Call the owner</span><Phone size={15} aria-hidden="true" /></span></a>
          </div>
        </div>
        <Link className="restaurant-hero__corner-link" href="/banquets-events">Looking for the hall? <ArrowUpRight size={14} aria-hidden="true" /></Link>
      </div>
    </section>
  );
}
