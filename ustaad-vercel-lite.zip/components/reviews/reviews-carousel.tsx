"use client";

import { useState } from "react";
import { ArrowLeft, ArrowRight, ExternalLink } from "lucide-react";
import { reviewPlaceholders } from "@/data/reviews";
import { siteData } from "@/data/site";

export function ReviewsCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const previous = () => setActiveIndex((index) => (index - 1 + reviewPlaceholders.length) % reviewPlaceholders.length);
  const next = () => setActiveIndex((index) => (index + 1) % reviewPlaceholders.length);

  return (
    <div className="reviews-carousel" role="region" aria-roledescription="carousel" aria-label="Google review placeholders">
      <div className="reviews-grid">
        {reviewPlaceholders.map((review, index) => (
          <article key={review.id} className={`review-card${activeIndex === index ? " review-card--active" : ""}`} aria-label={`Review placeholder ${index + 1} of ${reviewPlaceholders.length}`}>
            <span className="review-card__quote" aria-hidden="true">“</span>
            <p className="review-card__text">{review.quote}</p>
            <div className="review-card__bottom"><span>{review.name}</span><span className="review-card__source">GOOGLE REVIEW</span></div>
          </article>
        ))}
      </div>
      <div className="reviews-carousel__controls">
        <span aria-live="polite" aria-atomic="true">Review placeholder {String(activeIndex + 1).padStart(2, "0")} / 03</span>
        <div className="reviews-carousel__arrows">
          <button type="button" onClick={previous} aria-label="Previous review placeholder"><ArrowLeft size={17} /></button>
          <button type="button" onClick={next} aria-label="Next review placeholder"><ArrowRight size={17} /></button>
        </div>
        <a href={siteData.reviewHref} target="_blank" rel="noopener noreferrer">Review us on Google <ExternalLink size={14} aria-hidden="true" /></a>
      </div>
    </div>
  );
}
