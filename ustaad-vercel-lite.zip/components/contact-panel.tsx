import { Compass, MapPin, Phone } from "lucide-react";
import { siteData } from "@/data/site";
import { ButtonLink } from "@/components/ui/button-link";

export function ContactPanel({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`contact-panel${compact ? " contact-panel--compact" : ""}`}>
      <div className="contact-panel__details">
        <div className="contact-detail">
          <span className="contact-detail__icon"><MapPin size={18} aria-hidden="true" /></span>
          <div><p className="footer-label">Our address</p><address>{siteData.address}</address></div>
        </div>
        <div className="contact-detail">
          <span className="contact-detail__icon"><Phone size={18} aria-hidden="true" /></span>
          <div><p className="footer-label">Call Ustaad</p><a href={siteData.phoneHref}>{siteData.phoneDisplay}</a></div>
        </div>
        <div className="contact-detail">
          <span className="contact-detail__icon"><span aria-hidden="true">◷</span></span>
          <div><p className="footer-label">Opening hours</p><p>{siteData.hours}</p></div>
        </div>
        <div className="contact-panel__actions">
          <ButtonLink href={siteData.directionsHref} external>Get directions</ButtonLink>
          <ButtonLink href={siteData.phoneHref} variant="outline">Call now</ButtonLink>
        </div>
      </div>
      <div className="map-frame">
        <iframe
          title="Map to Ustaad Cafe Restaurant Banquets in Kushaiguda"
          src={siteData.mapEmbedHref}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
        <a className="map-frame__badge" href={siteData.directionsHref} target="_blank" rel="noopener noreferrer">
          <Compass size={14} aria-hidden="true" /> Open in Google Maps
        </a>
      </div>
    </div>
  );
}
