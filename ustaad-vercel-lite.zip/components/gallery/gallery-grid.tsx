"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { galleryCategories, galleryItems, type GalleryCategory } from "@/data/gallery";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

export function GalleryGrid({ preview = false }: { preview?: boolean }) {
  const [category, setCategory] = useState<GalleryCategory | "All">("All");
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);
  const touchStartX = useRef<number | null>(null);
  const reduceMotion = useReducedMotion();
  const filtered = category === "All" ? galleryItems : galleryItems.filter((item) => item.category === category);
  const visibleItems = preview ? filtered.slice(0, 4) : filtered;
  const activeItem = activeIndex === null ? null : visibleItems[activeIndex];

  const close = useCallback(() => setActiveIndex(null), []);
  const showPrevious = useCallback(() => {
    setActiveIndex((current) => current === null ? null : (current - 1 + visibleItems.length) % visibleItems.length);
  }, [visibleItems.length]);
  const showNext = useCallback(() => {
    setActiveIndex((current) => current === null ? null : (current + 1) % visibleItems.length);
  }, [visibleItems.length]);
  const isOpen = activeIndex !== null;

  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusTimer = window.setTimeout(() => closeButtonRef.current?.focus(), 0);
    return () => {
      window.clearTimeout(focusTimer);
      document.body.style.overflow = previousOverflow;
      returnFocusRef.current?.focus();
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
      if (event.key === "ArrowLeft") showPrevious();
      if (event.key === "ArrowRight") showNext();
      if (event.key === "Tab") {
        const controls = Array.from(document.querySelectorAll<HTMLElement>(".lightbox button:not([disabled])"));
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isOpen, close, showNext, showPrevious]);

  const openLightbox = (index: number) => {
    returnFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setActiveIndex(index);
  };

  return (
    <>
      {!preview ? (
        <div className="gallery-filters" role="group" aria-label="Filter gallery photos">
          <button type="button" className={category === "All" ? "is-selected" : ""} aria-pressed={category === "All"} onClick={() => setCategory("All")}>All</button>
          {galleryCategories.map((item) => (
            <button key={item} type="button" className={category === item ? "is-selected" : ""} aria-pressed={category === item} onClick={() => setCategory(item)}>{item}</button>
          ))}
        </div>
      ) : null}

      <div className={`gallery-masonry${preview ? " gallery-masonry--preview" : ""}`}>
        {visibleItems.map((item, index) => (
          <motion.button
            key={item.id}
            type="button"
            className={`gallery-card gallery-card--${index % 4}`}
            onClick={() => openLightbox(index)}
            initial={reduceMotion ? false : { opacity: 1, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.12 }}
            transition={{ duration: 0.6, delay: reduceMotion ? 0 : (index % 4) * 0.055, ease: [0.22, 1, 0.36, 1] }}
            whileHover={reduceMotion ? undefined : { y: -3 }}
            whileTap={reduceMotion ? undefined : { scale: 0.99 }}
          >
            <PhotoPlaceholder variant={item.category === "Food" ? "kitchen" : item.category === "Ambience" ? "ambience" : "banquet"} label="Ustaad photo needed" />
            <span className="gallery-card__caption"><span><i>{item.category}</i><strong>{item.title}</strong></span><span className="gallery-card__view">VIEW ↗</span></span>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {activeItem ? (
          <motion.div
            className="lightbox"
            role="dialog"
            aria-modal="true"
            aria-label={`${activeItem.category} photo placeholder`}
            initial={reduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduceMotion ? 0.1 : 0.25 }}
            onMouseDown={(event) => { if (event.target === event.currentTarget) close(); }}
            onTouchStart={(event) => { touchStartX.current = event.touches[0]?.clientX ?? null; }}
            onTouchEnd={(event) => {
              const start = touchStartX.current;
              const end = event.changedTouches[0]?.clientX;
              if (start !== null && end !== undefined && Math.abs(end - start) > 48) (end < start ? showNext : showPrevious)();
              touchStartX.current = null;
            }}
          >
            <button className="lightbox__close" type="button" ref={closeButtonRef} onClick={close} aria-label="Close gallery photo"><X size={22} /></button>
            <button className="lightbox__arrow lightbox__arrow--previous" type="button" onClick={showPrevious} aria-label="Previous gallery photo"><ArrowLeft size={22} /></button>
            <div className="lightbox__content">
              <PhotoPlaceholder variant={activeItem.category === "Food" ? "kitchen" : activeItem.category === "Ambience" ? "ambience" : "banquet"} label="Ustaad photo needed" />
              <div className="lightbox__caption"><span>{activeItem.category}</span><strong>{activeItem.title}</strong><small>{activeItem.note}</small><span className="lightbox__count">{String(activeIndex! + 1).padStart(2, "0")} / {String(visibleItems.length).padStart(2, "0")}</span></div>
            </div>
            <button className="lightbox__arrow lightbox__arrow--next" type="button" onClick={showNext} aria-label="Next gallery photo"><ArrowRight size={22} /></button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  );
}
