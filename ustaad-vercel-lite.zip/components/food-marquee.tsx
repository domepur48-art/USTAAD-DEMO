import { foodCategories } from "@/data/site";

export function FoodMarquee() {
  const items = [...foodCategories, ...foodCategories];
  return (
    <>
      <p className="sr-only">Food at Ustaad: {foodCategories.join(", ")}.</p>
      <div className="food-marquee" aria-hidden="true">
        <div className="food-marquee__track">
          {items.map((item, index) => (
            <span className="food-marquee__item" key={`${item}-${index}`}>
              {item}<i aria-hidden="true">✦</i>
            </span>
          ))}
        </div>
      </div>
    </>
  );
}
