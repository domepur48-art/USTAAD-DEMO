"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowDown } from "lucide-react";

export function PageHero({
  eyebrow,
  title,
  description,
  target = "page-content",
}: {
  eyebrow: string;
  title: string;
  description: string;
  target?: string;
}) {
  const reduceMotion = useReducedMotion();
  const initial = reduceMotion ? false : { opacity: 1, y: 18 };
  return (
    <section id="page-hero" className="page-hero">
      <div className="page-shell page-hero__inner">
        <motion.p className="eyebrow" initial={initial} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>{eyebrow}</motion.p>
        <motion.h1 initial={initial} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: reduceMotion ? 0 : 0.08, ease: [0.22, 1, 0.36, 1] }}>{title}</motion.h1>
        <motion.p className="page-hero__description" initial={initial} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: reduceMotion ? 0 : 0.17, ease: [0.22, 1, 0.36, 1] }}>{description}</motion.p>
        <a className="page-hero__scroll" href={`#${target}`} aria-label="Scroll to page content"><ArrowDown size={15} aria-hidden="true" /></a>
      </div>
      <div className="page-hero__line" aria-hidden="true"><span /></div>
    </section>
  );
}
