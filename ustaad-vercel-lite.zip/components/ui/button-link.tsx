"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { ReactNode } from "react";

type ButtonLinkProps = {
  href: string;
  children: ReactNode;
  variant?: "gold" | "outline" | "text";
  className?: string;
  external?: boolean;
  ariaLabel?: string;
};

export function ButtonLink({
  href,
  children,
  variant = "gold",
  className = "",
  external = false,
  ariaLabel,
}: ButtonLinkProps) {
  const reduceMotion = useReducedMotion();

  return (
    <a
      className={`button-link button-link--${variant} ${className}`.trim()}
      href={href}
      aria-label={ariaLabel}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
    >
      <motion.span
        className="button-link__content"
        whileHover={reduceMotion ? undefined : { y: -1 }}
        whileTap={reduceMotion ? undefined : { scale: 0.985 }}
        transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
      >
        <span>{children}</span>
        <ArrowUpRight className="button-link__arrow" size={16} aria-hidden="true" />
      </motion.span>
    </a>
  );
}
