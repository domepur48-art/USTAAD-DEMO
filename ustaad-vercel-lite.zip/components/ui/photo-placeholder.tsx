export function PhotoPlaceholder({
  label = "Ustaad photo needed",
  variant = "arch",
  compact = false,
  className = "",
}: {
  label?: string;
  variant?: "arch" | "kitchen" | "banquet" | "ambience";
  compact?: boolean;
  className?: string;
}) {
  return (
    <div
      className={`photo-placeholder photo-placeholder--${variant}${compact ? " photo-placeholder--compact" : ""} ${className}`.trim()}
      role="img"
      aria-label={label}
    >
      <div className="photo-placeholder__geometry" aria-hidden="true">
        <span className="photo-placeholder__arch photo-placeholder__arch--outer" />
        <span className="photo-placeholder__arch photo-placeholder__arch--inner" />
        <span className="photo-placeholder__sun" />
        <span className="photo-placeholder__rule photo-placeholder__rule--left" />
        <span className="photo-placeholder__rule photo-placeholder__rule--right" />
      </div>
      <span className="photo-placeholder__label">{label}</span>
    </div>
  );
}
