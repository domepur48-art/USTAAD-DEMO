import Link from "next/link";
import { ArrowDown, ArrowUpRight, MapPin, MessageCircle, Phone, Sparkles } from "lucide-react";
import { banquetPageContent } from "@/data/banquets";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

export function BanquetHero() {
  return (
    <section className="banquet-hero" aria-labelledby="banquet-hero-title">
      <PhotoPlaceholder variant="banquet" label="Ustaad single banquet hall" />
      <div className="banquet-hero__overlay" aria-hidden="true" />
      <div className="page-shell banquet-hero__content">
        <div className="banquet-hero__copy">
          <p className="banquet-hero__index">02 <i /> THE SINGLE HALL</p>
          <p className="eyebrow"><MapPin size={13} aria-hidden="true" /> {banquetPageContent.eyebrow}</p>
          <Sparkles className="banquet-hero__sparkle" size={28} aria-hidden="true" />
          <h1 id="banquet-hero-title">One hall for<br /><em>every occasion.</em></h1>
          <p className="banquet-hero__description">{banquetPageContent.introduction}</p>
          <div className="banquet-hero__actions">
            <a className="button-link button-link--gold" href="#faq"><span className="button-link__content"><span>Plan your event</span><ArrowDown size={15} aria-hidden="true" /></span></a>
            <a className="button-link button-link--whatsapp" href={siteData.whatsappHref} target="_blank" rel="noopener noreferrer"><span className="button-link__content"><span>WhatsApp the owner</span><MessageCircle size={15} aria-hidden="true" /></span></a>
          </div>
        </div>
        <div className="banquet-hero__side-actions">
          <a className="banquet-hero__corner-link" href={siteData.phoneHref}><Phone size={14} aria-hidden="true" /> Call the owner</a>
          <Link className="banquet-hero__corner-link" href="/restaurant">Looking for the restaurant? <ArrowUpRight size={14} aria-hidden="true" /></Link>
        </div>
      </div>
    </section>
  );
}
