import { BriefcaseBusiness, Cake, Car, Flower2, PanelsTopLeft, Sparkles, Utensils, Users, Wind, type LucideIcon } from "lucide-react";
import { banquetFacilities, eventTypes } from "@/data/banquets";
import { banquetPageContent } from "@/data/banquets";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";

const eventIcons: Record<string, LucideIcon> = { sparkles: Sparkles, rings: Sparkles, cake: Cake, briefcase: BriefcaseBusiness, users: Users };
const facilityIcons: Record<string, LucideIcon> = { wind: Wind, car: Car, panels: PanelsTopLeft, flower: Flower2, utensils: Utensils };

export function EventDetails() {
  return (
    <>
      <section className="section-space event-types-section" id="page-content">
        <div className="page-shell">
          <Reveal><SectionHeading eyebrow={banquetPageContent.eventSection.eyebrow} title={banquetPageContent.eventSection.title} description={banquetPageContent.eventSection.description} /></Reveal>
          <div className="event-type-grid">
            {eventTypes.map((event, index) => {
              const Icon = eventIcons[event.icon] ?? Sparkles;
              return <Reveal className="event-type-card" key={event.id} delay={index * 0.04}><span className="event-type-card__number">0{index + 1}</span><Icon size={22} strokeWidth={1.4} aria-hidden="true" /><h3>{event.name}</h3><span className="event-type-card__rule" aria-hidden="true" /></Reveal>;
            })}
          </div>
        </div>
      </section>
      <section className="section-space facilities-section">
        <div className="page-shell facilities-layout">
          <Reveal><SectionHeading eyebrow={banquetPageContent.facilitySection.eyebrow} title={banquetPageContent.facilitySection.title} description={banquetPageContent.facilitySection.description} /></Reveal>
          <div className="facility-grid">
            {banquetFacilities.map((facility, index) => {
              const Icon = facilityIcons[facility.icon] ?? Utensils;
              return <Reveal className="facility-card" key={facility.id} delay={index * 0.035}><Icon size={20} strokeWidth={1.4} aria-hidden="true" /><span>{facility.label}</span><small>{facility.detail}</small></Reveal>;
            })}
          </div>
        </div>
      </section>
    </>
  );
}
