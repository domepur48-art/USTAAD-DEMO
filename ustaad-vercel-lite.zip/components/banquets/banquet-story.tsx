"use client";

import { ArrowDown, MessageCircle, Phone } from "lucide-react";
import { banquetScenes, banquetPageContent } from "@/data/banquets";
import { siteData } from "@/data/site";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";

const Actions = () => <div className="banquet-story__scene-actions"><a href={siteData.phoneHref} className="button-link button-link--gold">Call the owner</a><a href={siteData.whatsappHref} className="button-link button-link--outline button-link--whatsapp" target="_blank" rel="noopener noreferrer">WhatsApp</a></div>;

export function BanquetStory() {
  return <section className="banquet-story-section" aria-labelledby="banquet-story-title">
    <div className="banquet-story__desktop">
      <div className="banquet-story__desktop-intro page-shell">
        <p className="eyebrow">FIVE OCCASIONS · ONE CONVERSATION</p><h2 id="banquet-story-title">{banquetPageContent.storyTitle}</h2><p>{banquetPageContent.storyDescription}</p><span className="banquet-story__scroll-cue"><ArrowDown size={14} /> Scroll to explore one occasion at a time</span>
      </div>
      <div className="banquet-story__sticky-scenes">
        {banquetScenes.map((scene) => <article className="banquet-story__sticky-scene" key={scene.id}>
          <div className="banquet-story__sticky-inner page-shell">
            <div className="banquet-story__sticky-copy"><span className="banquet-story__scene-number">{scene.number}</span><h3>{scene.title}</h3><p>{scene.description}</p>{scene.id === "final" && <Actions />}<div className="banquet-story__scene-progress"><span>STORY</span><i>{scene.number} / 05</i></div></div>
            <div className={`banquet-story__sticky-visual banquet-story__sticky-visual--${scene.id}`}><PhotoPlaceholder variant="banquet" label={scene.imageLabel} /><span className="banquet-story__visual-caption">{scene.number} <span>{scene.title}</span></span></div>
          </div>
        </article>)}
      </div>
    </div>
    <div className="banquet-story__mobile page-shell"><div className="banquet-story__mobile-heading"><p className="eyebrow">FIVE OCCASIONS · ONE CONVERSATION</p><h2>{banquetPageContent.storyTitle}</h2><p>{banquetPageContent.storyDescription}</p></div>{banquetScenes.map((scene) => <article className={`banquet-story__mobile-scene banquet-story__mobile-scene--${scene.id}`} key={scene.id}><PhotoPlaceholder variant="banquet" compact label={scene.imageLabel} /><div><span className="banquet-story__scene-number">{scene.number}</span><h3>{scene.title}</h3><p>{scene.description}</p>{scene.id === "final" && <Actions />}</div></article>)}<div className="banquet-story__mobile-actions"><a href={siteData.phoneHref} className="button-link button-link--gold"><span className="button-link__content"><span>Call the owner</span><Phone size={15} /></span></a><a href={siteData.whatsappHref} className="button-link button-link--outline button-link--whatsapp" target="_blank" rel="noopener noreferrer"><span className="button-link__content"><span>WhatsApp</span><MessageCircle size={15} /></span></a></div></div>
  </section>;
}
