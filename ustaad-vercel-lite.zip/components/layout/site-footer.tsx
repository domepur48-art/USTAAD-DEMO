import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { navigation, siteData } from "@/data/site";

export function SiteFooter() {
  return (
    <footer id="site-footer" className="site-footer">
      <div className="site-footer__top page-shell">
        <div className="site-footer__brand-block">
          <p className="eyebrow">WEAVERS COLONY · KUSHAIGUDA</p>
          <h2>{siteData.footerTagline}</h2>
          <a className="footer-call" href={siteData.phoneHref}>{siteData.phoneDisplay}<ArrowUpRight size={17} aria-hidden="true" /></a>
        </div>
        <div className="site-footer__details">
          <div>
            <p className="footer-label">Find us</p>
            <p>{siteData.address}</p>
            <a href={siteData.directionsHref} target="_blank" rel="noopener noreferrer">Get directions <ArrowUpRight size={14} aria-hidden="true" /></a>
          </div>
          <div>
            <p className="footer-label">Opening hours</p>
            <p>{siteData.hours}</p>
          </div>
          <div>
            <p className="footer-label">Explore</p>
            <ul>{navigation.map((item) => <li key={item.href}><Link href={item.href}>{item.label}</Link></li>)}</ul>
          </div>
        </div>
      </div>
      <div className="site-footer__bottom page-shell">
        <span>{siteData.copyright}</span>
        <span>{siteData.footerCredit}</span>
      </div>
    </footer>
  );
}
