"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { navigation, siteData } from "@/data/site";

export function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(pathname !== "/");
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 34 || pathname !== "/");
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, [pathname]);

  useEffect(() => setMenuOpen(false), [pathname]);

  return (
      <header className={`site-header${pathname === "/" ? " site-header--hero" : ""}${scrolled ? " site-header--scrolled" : ""}`}>
        <div className="site-header__inner page-shell">
        <Link href="/" className="brand" aria-label="Ustaad Bakers Restaurant and Banquets home">
          <img className="brand__logo-image" src="/images/ustaad-logo.png" alt="Ustaad Bakers Restaurant & Banquets" />
        </Link>

        <nav className="site-nav" aria-label="Main navigation">
          {navigation.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={pathname === item.href ? "page" : undefined}
              className={pathname === item.href ? "is-active" : ""}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <a className="header-call" href={siteData.phoneHref}>
          <Phone size={15} aria-hidden="true" />
          <span>Call now</span>
        </a>

        <button
          type="button"
          className="menu-toggle"
          aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={menuOpen}
          aria-controls="mobile-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      <div
        id="mobile-navigation"
        className={`mobile-nav${menuOpen ? " mobile-nav--open" : ""}`}
        hidden={!menuOpen}
      >
        <nav className="mobile-nav__links page-shell" aria-label="Mobile navigation">
          {navigation.map((item, index) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={pathname === item.href ? "page" : undefined}
              onClick={() => setMenuOpen(false)}
            >
              <span className="mobile-nav__number">0{index + 1}</span>
              <span>{item.label}</span>
            </Link>
          ))}
          <a className="mobile-nav__call" href={siteData.phoneHref}>
            <Phone size={16} aria-hidden="true" /> Call Ustaad · {siteData.phoneDisplay}
          </a>
        </nav>
      </div>
    </header>
  );
}
