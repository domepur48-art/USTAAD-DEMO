"use client";

import { useEffect, useState } from "react";
import { Compass, MessageCircle, Phone } from "lucide-react";
import { siteData } from "@/data/site";

export function MobileActionBar() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const hero = document.getElementById("home-hero") ?? document.getElementById("page-hero");
    const footer = document.getElementById("site-footer");
    if (!hero || !footer || !("IntersectionObserver" in window)) {
      setVisible(true);
      return;
    }

    let heroPassed = false;
    let footerVisible = false;
    const sync = () => setVisible(heroPassed && !footerVisible);
    const heroObserver = new IntersectionObserver(([entry]) => {
      heroPassed = !entry.isIntersecting && entry.boundingClientRect.bottom < 0;
      sync();
    }, { threshold: 0 });
    const footerObserver = new IntersectionObserver(([entry]) => {
      footerVisible = entry.isIntersecting;
      sync();
    }, { threshold: 0.01 });

    heroObserver.observe(hero);
    footerObserver.observe(footer);
    return () => {
      heroObserver.disconnect();
      footerObserver.disconnect();
    };
  }, []);

  return (
    <div className={`mobile-action-bar${visible ? " mobile-action-bar--visible" : ""}`} aria-label="Quick contact actions">
      <a href={siteData.phoneHref} aria-label={`Call Ustaad at ${siteData.phoneDisplay}`}>
        <Phone size={17} aria-hidden="true" /><span>Call</span>
      </a>
      <a className="mobile-action-bar__whatsapp" href={siteData.whatsappHref} target="_blank" rel="noopener noreferrer" aria-label="Message Ustaad on WhatsApp">
        <MessageCircle size={17} aria-hidden="true" /><span>WhatsApp</span>
      </a>
      <a href={siteData.directionsHref} target="_blank" rel="noopener noreferrer" aria-label="Get directions to Ustaad">
        <Compass size={17} aria-hidden="true" /><span>Directions</span>
      </a>
    </div>
  );
}
