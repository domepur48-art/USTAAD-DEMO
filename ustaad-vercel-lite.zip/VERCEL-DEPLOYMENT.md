# Ustaad Website — Vercel Deployment Guide

## Recommended method: upload the smaller project folder

1. Download and unzip `ustaad-vercel-lite.zip` on your computer. This package is below Vercel's 25 MB browser-upload limit and excludes only superseded duplicate image files; the images used by the website are preserved.
2. Open [Vercel New Project](https://vercel.com/new).
3. Sign in or create a free Vercel account.
4. Choose **Add New… → Project**.
5. Drag the unzipped `ustaad` project folder into the upload area, or choose **Import Third-Party / Upload** if shown.
6. Vercel should detect **Next.js** automatically.
7. Use these settings:
   - **Framework Preset:** Next.js
   - **Root Directory:** `./`
   - **Build Command:** `npm run build`
   - **Output Directory:** leave the default
   - **Install Command:** `npm install`
8. Click **Deploy**.
9. Wait for the build to finish, then open the generated `.vercel.app` URL.

The full source archive is also available as `ustaad-vercel.zip`, but the lite package is the correct one for direct browser upload.

## If Vercel only accepts a Git repository

1. Create a new repository on GitHub, for example `ustaad-restaurant-website`.
2. Upload all files and folders from the unzipped project folder.
3. Do not upload `node_modules` or `.next` if they are present.
4. In Vercel, click **Add New… → Project**.
5. Select **Import** next to the GitHub repository.
6. Keep the same Next.js settings listed above and click **Deploy**.

## Important checks before deployment

- Keep `package.json` in the project root.
- Keep the `app`, `components`, `data`, `public`, and `lib` folders in the same structure.
- All images are already stored inside `public/images`.
- Do not change the image paths.
- The WhatsApp and phone links work without environment variables.
- No database or paid Vercel feature is required for this website.

## Free-tier notes

The Vercel Hobby/free plan is sufficient for this static Next.js restaurant website. It provides a Vercel subdomain such as:

```text
https://your-project-name.vercel.app
```

A custom domain can be connected later through **Project Settings → Domains**. The domain itself may require separate registration/payment.

## After deployment

Check these URLs:

- `/`
- `/restaurant`
- `/banquets-events`
- `/gallery`
- `/about-reviews`
- `/contact`

If Vercel shows a build error, open **Deployments → failed deployment → Build Logs** and check the first error rather than the final summary.
