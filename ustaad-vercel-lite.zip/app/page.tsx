import { HomePage } from "@/components/home/home-page";
import { buildPageMetadata } from "@/data/metadata";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.home.title, pageSeo.home.description, "/");

export default function Page() {
  return <HomePage />;
}
