import { ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { ReviewsCarousel } from "@/components/reviews/reviews-carousel";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";
import { siteData } from "@/data/site";
import { buildPageMetadata } from "@/data/metadata";
import { secondaryPages } from "@/data/pages";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.about.title, pageSeo.about.description, "/about-reviews");

export default function AboutReviewsPage() {
  return (
    <main id="main-content">
      <PageHero eyebrow={secondaryPages.about.hero.eyebrow} title={secondaryPages.about.hero.title} description={secondaryPages.about.hero.description} target="about-content" />
      <section className="section-space about-story-section" id="about-content">
        <div className="page-shell about-story-layout">
          <Reveal className="about-story-layout__copy">
            <p className="eyebrow">{secondaryPages.about.storyEyebrow}</p>
            <h2>{secondaryPages.about.storyTitle}<br /><em>{secondaryPages.about.storyEmphasis}</em></h2>
            <p className="about-placeholder">{secondaryPages.about.storyPlaceholder}</p>
            <p>{secondaryPages.about.location}</p>
            <p className="bakery-note">{secondaryPages.about.bakeryLine} <strong>{secondaryPages.about.bakeryConfirmation}</strong></p>
          </Reveal>
          <Reveal className="about-story-layout__visual"><PhotoPlaceholder variant="ambience" label="Ustaad photo needed" /></Reveal>
        </div>
      </section>
      <section className="section-space reviews-section reviews-page-section">
        <div className="page-shell">
          <Reveal><SectionHeading eyebrow={secondaryPages.about.reviewEyebrow} title={secondaryPages.about.reviewTitle} description={secondaryPages.about.reviewDescription} /></Reveal>
          <ReviewsCarousel />
          <a className="text-link reviews-page-link" href={siteData.reviewHref} target="_blank" rel="noopener noreferrer">Review us on Google <ArrowUpRight size={15} aria-hidden="true" /></a>
        </div>
      </section>
    </main>
  );
}
