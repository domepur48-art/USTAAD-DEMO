import { ArrowUpRight } from "lucide-react";
import { ContactPanel } from "@/components/contact-panel";
import { PageHero } from "@/components/page-hero";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";
import { Reveal } from "@/components/ui/reveal";
import { siteData } from "@/data/site";
import { buildPageMetadata } from "@/data/metadata";
import { secondaryPages } from "@/data/pages";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.contact.title, pageSeo.contact.description, "/contact");

export default function ContactPage() {
  return (
    <main id="main-content">
      <PageHero eyebrow={secondaryPages.contact.hero.eyebrow} title={secondaryPages.contact.hero.title} description={secondaryPages.contact.hero.description} target="contact-content" />
      <section className="section-space contact-page-section" id="contact-content">
        <div className="page-shell">
          <ContactPanel />
          <div className="building-card">
            <Reveal className="building-card__photo"><PhotoPlaceholder variant="arch" label="Ustaad photo needed" /></Reveal>
            <div className="building-card__copy"><p className="eyebrow">{secondaryPages.contact.buildingEyebrow}</p><h2>{secondaryPages.contact.buildingTitle}<br /><em>{secondaryPages.contact.buildingEmphasis}</em></h2><p>{secondaryPages.contact.buildingDescription}</p><span className="building-card__note">{secondaryPages.contact.buildingImageNote}</span><a className="text-link" href={siteData.directionsHref} target="_blank" rel="noopener noreferrer">Open directions <ArrowUpRight size={15} aria-hidden="true" /></a></div>
          </div>
        </div>
      </section>
    </main>
  );
}
