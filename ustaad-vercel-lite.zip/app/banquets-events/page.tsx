import { ArrowUpRight, MessageCircle, Phone } from "lucide-react";
import { BanquetHero } from "@/components/banquets/banquet-hero";
import { BanquetStory } from "@/components/banquets/banquet-story";
import { EventDetails } from "@/components/banquets/event-details";
import { FaqAccordion } from "@/components/banquets/faq-accordion";
import { PhotoPlaceholder } from "@/components/ui/photo-placeholder";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";
import { siteData } from "@/data/site";
import { banquetPageContent, eventTypes } from "@/data/banquets";
import { buildPageMetadata } from "@/data/metadata";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.banquets.title, pageSeo.banquets.description, "/banquets-events");

export default function BanquetsPage() {
  return (
    <main id="main-content">
      <BanquetHero />
      <EventDetails />
      <BanquetStory />
      <section className="section-space event-gallery-section">
        <div className="page-shell">
          <Reveal><SectionHeading eyebrow={banquetPageContent.gallerySection.eyebrow} title={banquetPageContent.gallerySection.title} description={banquetPageContent.gallerySection.description} /></Reveal>
          <div className="event-gallery-grid">
            {eventTypes.map((event, index) => (
              <Reveal className={`event-gallery-card event-gallery-card--${index + 1}`} key={event.id} delay={index * 0.04}>
                <PhotoPlaceholder variant="banquet" compact className={`event-gallery-photo event-gallery-photo--${event.id}`} label={`${event.name} at Ustaad Banquets`} />
                <span><i>0{index + 1}</i>{event.name}<small>Ustaad Banquets</small></span>
              </Reveal>
            ))}
          </div>
          <p className="placeholder-note">Capacity: [number] guests · Facilities: [AC, parking, stage, décor, catering]</p>
        </div>
      </section>
      <section className="section-space faq-section" id="faq">
        <div className="page-shell faq-layout">
          <Reveal><SectionHeading eyebrow={banquetPageContent.faqSection.eyebrow} title={banquetPageContent.faqSection.title} description={banquetPageContent.faqSection.description} /></Reveal>
          <FaqAccordion />
        </div>
      </section>
      <section className="banquet-endcap">
        <div className="page-shell banquet-endcap__inner">
          <p className="eyebrow">{banquetPageContent.endcapEyebrow}</p>
          <h2>{banquetPageContent.storyTitle}</h2>
          <p>{banquetPageContent.endcapDescription}</p>
          <div className="banquet-endcap__actions">
            <a className="button-link button-link--gold" href={siteData.phoneHref}><span className="button-link__content"><span>Call the owner</span><Phone size={16} aria-hidden="true" /></span></a>
            <a className="button-link button-link--outline" href={siteData.whatsappHref} target="_blank" rel="noopener noreferrer"><span className="button-link__content"><span>WhatsApp</span><MessageCircle size={16} aria-hidden="true" /></span></a>
          </div>
          <a className="text-link" href={siteData.directionsHref} target="_blank" rel="noopener noreferrer">Find Ustaad in Kushaiguda <ArrowUpRight size={15} aria-hidden="true" /></a>
        </div>
      </section>
    </main>
  );
}
