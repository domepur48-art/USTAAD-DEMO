import type { MetadataRoute } from "next";
import { siteData } from "@/data/site";

const pages = ["", "/banquets-events", "/gallery", "/about-reviews", "/contact"];

export default function sitemap(): MetadataRoute.Sitemap {
  return pages.map((page, index) => ({
    url: new URL(page, siteData.domain).toString(),
    lastModified: new Date(),
    changeFrequency: index === 0 ? "weekly" : "monthly",
    priority: index === 0 ? 1 : 0.7,
  }));
}
