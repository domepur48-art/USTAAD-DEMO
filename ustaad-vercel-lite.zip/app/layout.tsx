import type { Metadata } from "next";
import { DM_Sans, Playfair_Display } from "next/font/google";
import { MobileActionBar } from "@/components/layout/mobile-action-bar";
import { SiteFooter } from "@/components/layout/site-footer";
import { SiteHeader } from "@/components/layout/site-header";
import { restaurantSchema } from "@/data/restaurant-schema";
import { siteData } from "@/data/site";
import "./globals.css";

const dmSans = DM_Sans({ variable: "--font-dm-sans", subsets: ["latin"], display: "swap" });
const playfair = Playfair_Display({ variable: "--font-playfair", subsets: ["latin"], display: "swap", weight: ["400", "500", "600", "700"] });

export const metadata: Metadata = {
  metadataBase: new URL(siteData.domain),
  title: { default: "Ustaad Cafe Restaurant Banquets", template: "%s · Ustaad" },
  description: "Biryani, kebabs, Indian and Chinese favourites, seafood and celebrations in Kushaiguda, Secunderabad.",
  applicationName: siteData.name,
  openGraph: {
    type: "website",
    locale: "en_IN",
    siteName: siteData.name,
    title: "Ustaad Cafe Restaurant Banquets | Kushaiguda",
    description: "A complete restaurant and one single banquet hall for meals, celebrations and moments worth gathering for.",
    images: [{ url: new URL("/opengraph-image", siteData.domain).toString(), width: 1200, height: 630, alt: `${siteData.name} in Kushaiguda` }],
  },
  twitter: { card: "summary_large_image", title: "Ustaad Cafe Restaurant Banquets", description: "A complete restaurant and one single banquet hall for meals, celebrations and moments worth gathering for.", images: [new URL("/opengraph-image", siteData.domain).toString()] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const safeSchema = JSON.stringify(restaurantSchema).replace(/</g, "\\u003c");
  return (
    <html lang="en" className={`${dmSans.variable} ${playfair.variable}`}>
      <body>
        <a className="skip-link" href="#main-content">Skip to content</a>
        <SiteHeader />
        {children}
        <SiteFooter />
        <MobileActionBar />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeSchema }} />
      </body>
    </html>
  );
}
