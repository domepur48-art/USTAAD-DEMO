import { GalleryGrid } from "@/components/gallery/gallery-grid";
import { PageHero } from "@/components/page-hero";
import { buildPageMetadata } from "@/data/metadata";
import { secondaryPages } from "@/data/pages";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.gallery.title, pageSeo.gallery.description, "/gallery");

export default function GalleryPage() {
  return (
    <main id="main-content">
      <PageHero eyebrow={secondaryPages.gallery.hero.eyebrow} title={secondaryPages.gallery.hero.title} description={secondaryPages.gallery.hero.description} target="gallery-content" />
      <section className="section-space gallery-page-section" id="gallery-content">
        <div className="page-shell">
          <p className="gallery-page-note"><span /> PHOTOGRAPHY UPDATE <span>{secondaryPages.gallery.photoNotice}</span></p>
          <GalleryGrid />
        </div>
      </section>
    </main>
  );
}
