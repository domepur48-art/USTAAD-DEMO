import { ContactPanel } from "@/components/contact-panel";
import { Features } from "@/components/home/features";
import { InfoBar } from "@/components/home/info-bar";
import { InquiryForm } from "@/components/home/inquiry-form";
import { MenuPreview } from "@/components/home/menu-preview";
import { SignatureDishes } from "@/components/home/signature-dishes";
import { FoodMarquee } from "@/components/food-marquee";
import { RestaurantHero } from "@/components/restaurant/restaurant-hero";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";
import { buildPageMetadata } from "@/data/metadata";
import { homeContent } from "@/data/home";
import { pageSeo } from "@/data/seo";

export const metadata = buildPageMetadata(pageSeo.restaurant.title, pageSeo.restaurant.description, "/restaurant");

export default function RestaurantPage() {
  return (
    <main id="main-content">
      <RestaurantHero />
      <InfoBar />
      <div id="restaurant-content">
        <FoodMarquee />
        <SignatureDishes />
        <MenuPreview />
        <Features />
        <div className="page-shell inquiry-stack"><InquiryForm type="restaurant" /></div>
      </div>
      <section className="section-space home-contact-section" id="visit">
        <div className="page-shell">
          <Reveal><SectionHeading eyebrow="FIND YOUR WAY TO USTAAD" title={homeContent.contactTitle} description="Visit us in Weavers Colony, Kushaiguda. We’re open every day." /></Reveal>
          <ContactPanel />
        </div>
      </section>
    </main>
  );
}
