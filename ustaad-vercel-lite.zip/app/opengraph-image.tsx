import { ImageResponse } from "next/og";

export const alt = "Ustaad Cafe Restaurant Banquets in Kushaiguda";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          position: "relative",
          overflow: "hidden",
          background: "#FAF5EC",
          color: "#2F211A",
          fontFamily: "serif",
        }}
      >
        <div style={{ position: "absolute", inset: 0, display: "flex", background: "radial-gradient(ellipse at 82% 48%, rgba(138,154,107,.16), transparent 43%)" }} />
        <div style={{ position: "absolute", top: 63, left: 78, display: "flex", alignItems: "center", gap: 17 }}>
          <div style={{ width: 48, height: 54, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid #D4A55A", borderRadius: "25px 25px 4px 4px", color: "#6B2D3A", fontSize: 31 }}>U</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <span style={{ color: "#6B2D3A", fontSize: 27, letterSpacing: "2px" }}>Ustaad</span>
            <span style={{ fontFamily: "sans-serif", color: "#596844", fontSize: 10, letterSpacing: "4px" }}>RESTAURANT · BANQUETS</span>
          </div>
        </div>
        <div style={{ position: "absolute", top: 210, left: 80, display: "flex", flexDirection: "column", width: 720 }}>
          <span style={{ marginBottom: 21, color: "#93412B", fontFamily: "sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: "4px" }}>WEAVERS COLONY · KUSHAIGUDA</span>
          <span style={{ fontSize: 68, lineHeight: 1.05 }}>A complete restaurant,</span>
          <span style={{ color: "#6B2D3A", fontSize: 68, fontStyle: "italic", lineHeight: 1.08 }}>and a hall for every occasion.</span>
          <span style={{ marginTop: 26, color: "#2F211A", fontFamily: "sans-serif", fontSize: 17 }}>Biryani · Kebabs · Indian favourites · Seafood · Celebrations</span>
        </div>
        <div style={{ position: "absolute", top: 105, right: 96, width: 290, height: 425, display: "flex", border: "1px solid #D4A55A", background: "linear-gradient(135deg, #F0E6D6, #E7DEC9 65%)", boxShadow: "18px 20px 0 #C4673F" }}>
          <div style={{ position: "absolute", inset: 27, display: "flex", justifyContent: "center", alignItems: "flex-end", border: "1px solid rgba(212,165,90,.35)" }}>
            <div style={{ width: 150, height: 320, border: "1px solid #D4A55A", borderBottom: "0px solid transparent", borderRadius: "100% 100% 0 0" }} />
          </div>
          <div style={{ position: "absolute", top: 126, left: 119, width: 50, height: 50, display: "flex", border: "1px solid #8A9A6B", borderRadius: "50%", background: "rgba(138,154,107,.12)" }} />
          <span style={{ position: "absolute", bottom: 22, left: 20, color: "#795528", fontFamily: "sans-serif", fontSize: 9, fontWeight: 700, letterSpacing: "2px" }}>A PLACE TO DINE · A PLACE TO CELEBRATE</span>
        </div>
        <div style={{ position: "absolute", right: 78, bottom: 45, left: 78, height: 1, display: "flex", background: "#D4A55A" }} />
      </div>
    ),
    { ...size },
  );
}
