# Ustaad Cafe Restaurant Banquets

Premium, front-end-only website for Ustaad Cafe Restaurant Banquets in Weavers Colony, Kushaiguda, Secunderabad. The design is intentionally photo-led in structure, but uses clearly labelled “Ustaad photo needed” cards until verified owner-supplied photography is available. No online ordering, delivery, reservations, enquiry forms, payment, account, API or database features are included.

## Visual palette

- Background: Warm Cream `#FAF5EC`
- Surface / cards: Soft Linen `#F0E6D6`
- Primary accent: Terracotta `#C4673F`
- Secondary accent: Sage Olive `#8A9A6B`
- Highlight: Muted Gold `#D4A55A`
- Deep accent: Burgundy Wine `#6B2D3A`
- Text / dark: Espresso Brown `#2F211A`

Small accent text uses darker on-family ink shades where needed for 4.5:1 contrast. The exact muted gold and sage remain decorative/emphasis colors on light surfaces; gold-fill actions use espresso text.

## Run locally

```bash
npm install
npm run dev
```

The development server binds to `0.0.0.0:3000` by default. `PORT` can override the runtime port. Build and run the production server with:

```bash
npm run build
npm start
```

## Content and design editing

- `data/site.ts`: exact name, address, phone, WhatsApp, hours, Maps links, navigation, cuisine list and footer facts.
- `data/home.ts`: Home page headings, dish placeholders/prices, reasons to visit, restaurant and banquet copy.
- `data/banquets.ts`: event types, banquet story scenes, unconfirmed facilities, FAQ questions/answers.
- `data/gallery.ts`: filters and gallery placeholder captions.
- `data/reviews.ts`: review-card placeholders; replace only with owner-verified Google review text and names.
- `data/images.ts`: dimensions, actual visible content, alt text, source and approval status for downloaded image files. Keep unapproved images out of rendered pages.
- `data/seo.ts` and `data/metadata.ts`: page title/description and route metadata.
- `data/menu.ts`: deliberately empty typed future-menu collection. Do not publish a Menu page until the owner supplies a confirmed menu and prices.
- `components/` and `app/globals.css`: layout, motion and visual presentation. Five public pages are `/`, `/banquets-events`, `/gallery`, `/about-reviews` and `/contact`; `public/manus-routes.json` lists them.

The sitemap and Restaurant JSON-LD use the existing official site domain in `data/site.ts`. Replace that value if the launch domain changes.

## Photography note

The specified official-site files are saved in `public/images/ustaad/` and catalogued in `data/images.ts`. All eight numbered food gallery images show a visible “AI GENERATED” watermark; `quality-promise.jpg` duplicates `img-06.jpg`. The 1024×1024 logo and banner are the same red Ustaad/Bakers Restaurant & Banquets lockup. These files are not rendered because the food images are not verified real Ustaad photography and the bakery mark needs owner confirmation. The expected `assets/ustaad-exterior.png` (408×544) was not present in the uploads or workspace, so the exterior card is a designed placeholder rather than a substitute image. Replace placeholders only with approved Ustaad-owned photographs and factual alt text.

## Replace before launch

- Replace every “Ustaad photo needed” placeholder with suitable, higher-resolution Ustaad-owned food, restaurant, exterior, banquet and event photographs; confirm that the downloaded official-site assets, if used, are appropriate and authorized. Do not use stock or competitor imagery.
- Supply the exterior photo at the specified 408×544 portrait size (or a higher-resolution original); use it only in cards, never as a full-width hero/background.
- Confirm the WhatsApp number is active at `+91 97097 00690` and the provided link reaches the owner.
- Confirm whether bakery service is offered before retaining any “Bakers” claim.
- Replace `[4.x] from [N] Google reviews`, each `[Real Google review text]` and `[Reviewer name]`, and the dish `₹[price]` placeholders with verified values; provide the correct direct Google review link.
- Confirm the owner story (`[Owner to provide the Ustaad story]`), banquet capacity (`[number] guests`), each listed facility (`[AC, parking, stage, décor, catering]`), and event photographs/details.
- Confirm map listing/directions destination and all address/phone/hours with the owner before public launch.
- Add the Menu page when the menu is ready; first populate the empty `data/menu.ts` with owner-confirmed items and prices.
- Set the final site domain in `data/site.ts` before launch if `www.ustaadrestaurant.in` will not remain the canonical domain.

The website is a preview implementation; deployment/publication is a separate step.


## Mobile Lighthouse snapshot

The warm-palette local production build was audited on all five routes using Lighthouse’s mobile configuration. Scores (Performance / Accessibility / Best Practices / SEO): Home 93 / 100 / 100 / 100; Banquets & Events 94 / 100 / 100 / 100; Gallery 97 / 100 / 100 / 100; About & Reviews 90 / 100 / 100 / 100; Contact 94 / 100 / 100 / 100. All routes meet the 90+ target in each category. Re-run after publication and after photography/domain changes; actual scores can vary with hosting and third-party map/network behavior.
