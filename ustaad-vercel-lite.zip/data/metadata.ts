import type { Metadata } from "next";
import { siteData } from "@/data/site";

export function buildPageMetadata(title: string, description: string, route: string): Metadata {
  const shareImage = new URL("/opengraph-image", siteData.domain).toString();
  return {
    title,
    description,
    alternates: { canonical: route },
    openGraph: {
      title,
      description,
      siteName: siteData.name,
      type: "website",
      url: route,
      locale: "en_IN",
      images: [{ url: shareImage, width: 1200, height: 630, alt: `${siteData.name} in Kushaiguda` }],
    },
    twitter: { card: "summary_large_image", title, description, images: [shareImage] },
  };
}
