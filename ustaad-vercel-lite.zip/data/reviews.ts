export const reviewPlaceholders = [
  { id: "review-1", quote: "[Real Google review text]", name: "[Reviewer name]" },
  { id: "review-2", quote: "[Real Google review text]", name: "[Reviewer name]" },
  { id: "review-3", quote: "[Real Google review text]", name: "[Reviewer name]" },
] as const;
