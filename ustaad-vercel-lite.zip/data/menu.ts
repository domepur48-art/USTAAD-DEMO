export type MenuItem = {
  category: string;
  name: string;
  price: string;
  veg: boolean;
  spice: 0 | 1 | 2 | 3;
  bestseller: boolean;
  photo?: string;
  description?: string;
};

// Preview names are drawn from the current approved site copy; confirm prices before launch.
export const menu: MenuItem[] = [
  { category: "Biryani", name: "Chicken Biryani", price: "₹[price]", veg: false, spice: 2, bestseller: true, description: "Fragrant rice, warm spices and a generous serving for the table." },
  { category: "Kebabs", name: "Seekh Kebab", price: "₹[price]", veg: false, spice: 2, bestseller: true, description: "A smoky, richly seasoned favourite from the grill." },
  { category: "Chinese", name: "Veg Hakka Noodles", price: "₹[price]", veg: true, spice: 1, bestseller: false, description: "Wok-tossed noodles with crisp vegetables and house seasoning." },
  { category: "Seafood", name: "Tandoori Fish", price: "₹[price]", veg: false, spice: 2, bestseller: false, description: "Golden, spiced and made for sharing." },
];
