import { addressParts, allCuisines, siteData } from "@/data/site";

export const restaurantSchema = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: siteData.name,
  telephone: "+91 97097 00690",
  address: {
    "@type": "PostalAddress",
    streetAddress: addressParts.streetAddress,
    addressLocality: addressParts.addressLocality,
    addressRegion: addressParts.addressRegion,
    postalCode: addressParts.postalCode,
    addressCountry: addressParts.addressCountry,
  },
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: [
        "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
      ],
      opens: "06:00",
      closes: "23:30",
    },
  ],
  servesCuisine: [...allCuisines],
  hasMap: siteData.mapsSearchHref,
} as const;
