export type GalleryCategory = "Food" | "Ambience" | "Banquet" | "Events";

export const galleryCategories: GalleryCategory[] = ["Food", "Ambience", "Banquet", "Events"];

export const galleryItems: Array<{
  id: string;
  category: GalleryCategory;
  title: string;
  note: string;
}> = [
  { id: "food-1", category: "Food", title: "Ustaad photo needed", note: "Ustaad food photo needed" },
  { id: "food-2", category: "Food", title: "Ustaad photo needed", note: "Ustaad food photo needed" },
  { id: "ambience-1", category: "Ambience", title: "Ustaad photo needed", note: "Ustaad restaurant photo needed" },
  { id: "food-3", category: "Food", title: "Ustaad photo needed", note: "Ustaad food photo needed" },
  { id: "banquet-1", category: "Banquet", title: "Ustaad photo needed", note: "Ustaad banquet photo needed" },
  { id: "events-1", category: "Events", title: "Ustaad photo needed", note: "Ustaad event photo needed" },
  { id: "ambience-2", category: "Ambience", title: "Ustaad photo needed", note: "Ustaad restaurant photo needed" },
  { id: "banquet-2", category: "Banquet", title: "Ustaad photo needed", note: "Ustaad banquet photo needed" },
  { id: "events-2", category: "Events", title: "Ustaad photo needed", note: "Ustaad event photo needed" },
  { id: "food-4", category: "Food", title: "Ustaad photo needed", note: "Ustaad food photo needed" },
  { id: "ambience-3", category: "Ambience", title: "Ustaad photo needed", note: "Ustaad restaurant photo needed" },
  { id: "events-3", category: "Events", title: "Ustaad photo needed", note: "Ustaad event photo needed" },
];
