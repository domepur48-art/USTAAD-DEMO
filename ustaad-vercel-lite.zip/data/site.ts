export const siteData = {
  name: "Ustaad Cafe Restaurant Banquets",
  signage: "Restaurant · Single banquet hall",
  address: "606/G2 Part, Weavers Colony, Bhavana Nagar, Kushaiguda, Secunderabad, Telangana 500062",
  phoneDisplay: "+91 97097 00690",
  phoneHref: "tel:+919709700690",
  // confirm this number is on WhatsApp
  whatsappHref: "https://wa.me/919709700690",
  hours: "Monday to Sunday, 6:00 AM to 11:30 PM",
  hoursShort: "6:00 AM to 11:30 PM daily",
  mapQuery: "Ustaad Cafe Restaurant Banquets Kushaiguda",
  mapsSearchHref:
    "https://www.google.com/maps/search/?api=1&query=Ustaad+Cafe+Restaurant+Banquets+Kushaiguda",
  directionsHref:
    "https://www.google.com/maps/dir/?api=1&destination=Ustaad+Cafe+Restaurant+Banquets+Kushaiguda",
  mapEmbedHref:
    "https://www.google.com/maps?q=Ustaad+Cafe+Restaurant+Banquets+Kushaiguda&output=embed",
  reviewHref:
    "https://www.google.com/maps/search/?api=1&query=Ustaad+Cafe+Restaurant+Banquets+Kushaiguda",
  brandDescriptor: "Restaurant · Banquets",
  footerTagline: "Come for a meal. Gather for a moment.",
  footerCredit: "Website by Iarka Marketing",
  copyright: "© 2026 Ustaad Cafe Restaurant Banquets",
  domain: "https://www.ustaadrestaurant.in",
} as const;

export const navigation = [
  { label: "Home", href: "/" },
  { label: "Restaurant", href: "/restaurant" },
  { label: "Banquet", href: "/banquets-events" },
  { label: "Gallery", href: "/gallery" },
  { label: "About & Reviews", href: "/about-reviews" },
  { label: "Contact", href: "/contact" },
] as const;

export const foodCategories = [
  "Biryani",
  "Kebabs",
  "Tandoori",
  "Indian curries",
  "South Indian",
  "Chinese",
  "Seafood",
  "Shawarma",
  "Vegetarian",
  "Banquets",
] as const;

export const allCuisines = [
  "Biryani",
  "Kebabs and tandoori",
  "Indian curries",
  "South Indian",
  "Chinese",
  "Seafood",
  "Shawarma",
  "Vegetarian dishes",
] as const;

export const addressParts = {
  streetAddress: "606/G2 Part, Weavers Colony, Bhavana Nagar, Kushaiguda",
  addressLocality: "Secunderabad",
  addressRegion: "Telangana",
  postalCode: "500062",
  addressCountry: "IN",
} as const;
