export const secondaryPages = {
  gallery: {
    hero: {
      eyebrow: "FOOD · AMBIENCE · BANQUETS · EVENTS",
      title: "The Ustaad gallery.",
      description: "A considered look at the restaurant, its food and moments worth gathering for. Verified Ustaad photography will be added when available.",
    },
    photoNotice: "Authentic Ustaad images are being prepared.",
  },
  about: {
    hero: {
      eyebrow: "A PLACE WITH ROOM FOR EVERYONE",
      title: "Rooted in Kushaiguda.",
      description: "A restaurant for everyday dining, and a banquet hall for life’s celebrations.",
    },
    storyEyebrow: "THE STORY OF USTAAD",
    storyTitle: "A story worth",
    storyEmphasis: "telling properly.",
    storyPlaceholder: "[Owner to provide the Ustaad story]",
    location: "Ustaad Cafe Restaurant Banquets is in Weavers Colony, Kushaiguda, Secunderabad.",
    bakeryLine: "Restaurant, Banquets and Bakers under one roof",
    bakeryConfirmation: "[confirm with owner]",
    reviewEyebrow: "REAL WORDS, SHARED WITH PERMISSION",
    reviewTitle: "About & reviews.",
    reviewDescription: "Review text, reviewer names and rating details will be added after verification with the owner.",
  },
  contact: {
    hero: {
      eyebrow: "COME FIND US · KUSHAIGUDA",
      title: "The way to Ustaad.",
      description: "We’re in Weavers Colony, Bhavana Nagar, Kushaiguda, Secunderabad. Call us or open directions in Google Maps.",
    },
    buildingEyebrow: "LOOK FOR THIS BUILDING",
    buildingTitle: "Ustaad Cafe",
    buildingEmphasis: "Restaurant Banquets",
    buildingDescription: "Exterior photo pending. Please confirm the building image before launch.",
    buildingImageNote: "Ustaad photo needed · 408 × 544 portrait placeholder",
  },
} as const;
