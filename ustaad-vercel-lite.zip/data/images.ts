export type AuditedImage = {
  src: string;
  width: number;
  height: number;
  alt: string;
  displayApproved: boolean;
  note: string;
};

// Assets requested from the official site were opened and inspected. Food images carry
// an “AI GENERATED” watermark; the logo/banner are a red “USTAAD BAKERS RESTAURANT & BANQUETS” lockup.
// They are retained for owner review but deliberately not rendered until source/usage is confirmed.
export const auditedWebsiteImages: Record<string, AuditedImage> = {
  logo: {
    src: "/images/ustaad/logo.png",
    width: 1024,
    height: 1024,
    alt: "Red square Ustaad lockup with chef illustration and the words Bakers Restaurant & Banquets",
    displayApproved: false,
    note: "Official-site asset; bakery wording is unconfirmed and the mark does not fit the approved dark/gold direction. Confirm with owner before any use.",
  },
  banner: {
    src: "/images/ustaad/banner.jpg",
    width: 1024,
    height: 1024,
    alt: "Red square Ustaad lockup with chef illustration and the words Bakers Restaurant & Banquets",
    displayApproved: false,
    note: "Official-site image duplicates the logo lockup; bakery wording is unconfirmed. Confirm with owner before any use.",
  },
  qualityPromise: {
    src: "/images/ustaad/quality-promise.jpg",
    width: 640,
    height: 552,
    alt: "AI-generated-looking vegetable rice bowl with peas, carrots and broccoli, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; unsuitable as a verified Ustaad-owned food photo. Duplicates img-06.jpg.",
  },
  gallery01: {
    src: "/images/ustaad/img-01.jpg",
    width: 640,
    height: 552,
    alt: "Paneer cubes in orange curry, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery02: {
    src: "/images/ustaad/img-02.jpg",
    width: 640,
    height: 552,
    alt: "Paneer curry in a dark bowl, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery03: {
    src: "/images/ustaad/img-03.jpg",
    width: 640,
    height: 552,
    alt: "Vegetable fried rice with peas and carrots, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery04: {
    src: "/images/ustaad/img-04.jpg",
    width: 640,
    height: 552,
    alt: "Vegetable noodles with broccoli and peppers, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery05: {
    src: "/images/ustaad/img-05.jpg",
    width: 640,
    height: 552,
    alt: "Orange rice with green peas, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery06: {
    src: "/images/ustaad/img-06.jpg",
    width: 640,
    height: 552,
    alt: "Vegetable rice with peas, carrots and broccoli beside a bowl of raita, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use. Duplicated by quality-promise.jpg.",
  },
  gallery07: {
    src: "/images/ustaad/img-07.jpg",
    width: 640,
    height: 552,
    alt: "Vegetable rice with peas and carrots, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
  gallery08: {
    src: "/images/ustaad/img-08.jpg",
    width: 640,
    height: 552,
    alt: "Red-glazed round vegetable pieces in a bowl, visibly watermarked AI GENERATED",
    displayApproved: false,
    note: "Visible AI GENERATED watermark; do not present as an actual Ustaad dish photo until owner confirms intended use.",
  },
};

export const exteriorImage = {
  src: "/images/ustaad/ustaad-exterior.png",
  width: 408,
  height: 544,
  alt: "Ustaad Cafe Restaurant Banquets exterior, photo pending upload",
  available: false,
} as const;
