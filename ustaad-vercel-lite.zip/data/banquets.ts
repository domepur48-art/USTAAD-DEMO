export const eventTypes = [
  { id: "weddings", name: "Weddings", icon: "sparkles" },
  { id: "engagements", name: "Engagements", icon: "rings" },
  { id: "birthdays", name: "Birthdays", icon: "cake" },
  { id: "corporate", name: "Corporate functions", icon: "briefcase" },
  { id: "family", name: "Family functions", icon: "users" },
] as const;

export const banquetFacilities = [
  { id: "ac", label: "Air conditioning", detail: "[confirm with owner]", icon: "wind" },
  { id: "parking", label: "Parking", detail: "[confirm with owner]", icon: "car" },
  { id: "stage", label: "Stage", detail: "[confirm with owner]", icon: "panels" },
  { id: "decor", label: "Décor", detail: "[confirm with owner]", icon: "flower" },
  { id: "catering", label: "Catering", detail: "[confirm with owner]", icon: "utensils" },
] as const;

export const banquetScenes = [
  {
    id: "weddings",
    number: "01",
    title: "Weddings",
    description: "A gathering for a day that matters. Please call the owner for [details].",
    imageLabel: "Ustaad wedding photo needed",
  },
  {
    id: "engagements",
    number: "02",
    title: "Engagements",
    description: "Mark a new beginning with the people closest to you. Please call the owner for [details].",
    imageLabel: "Ustaad engagement photo needed",
  },
  {
    id: "birthdays-family",
    number: "03",
    title: "Birthdays / Family Occasions",
    description: "Bring family together for a birthday or special occasion. Please call the owner for [details].",
    imageLabel: "Ustaad birthday party photo",
  },
  {
    id: "corporate",
    number: "04",
    title: "Corporate Functions",
    description: "A place to bring colleagues together. Please call the owner for [details].",
    imageLabel: "Ustaad corporate event photo needed",
  },
  {
    id: "final",
    number: "05",
    title: "Family occasions",
    description:
      "Dates, packages and pricing are handled directly with the owner by phone or WhatsApp.",
    imageLabel: "Ustaad family event photo",
  },
] as const;

export const banquetFaqs = [
  {
    question: "Which occasions can I host at Ustaad Banquets?",
    answer: "Please call the owner for [details].",
  },
  {
    question: "What dates are available?",
    answer: "Please call the owner for [details].",
  },
  {
    question: "What are the banquet packages and prices?",
    answer: "Please call the owner for [details].",
  },
  {
    question: "What facilities are available?",
    answer: "Please call the owner for [details].",
  },
  {
    question: "How do I discuss an event?",
    answer: "Please call the owner for [details].",
  },
] as const;

export const banquetPageContent = {
  eyebrow: "USTAAD BANQUETS · KUSHAIGUDA",
  title: "One hall for every occasion.",
  introduction:
    "Ustaad has one banquet hall for weddings, engagements, birthdays, corporate and family functions. Dates, packages and pricing are handled directly with the owner by phone or WhatsApp.",
  storyTitle: "Celebrate with us.",
  storyDescription:
    "Five kinds of occasions. One hall. One conversation with the owner to discuss dates, packages and details.",
  capacity: "Capacity: [number] guests",
  facilities: "Facilities: [AC, parking, stage, décor, catering]",
  eventSection: {
    eyebrow: "FOR THE MOMENTS THAT MATTER",
    title: "Gather for something special.",
    description: "Weddings, engagements, birthdays, corporate and family functions. Speak with the owner about dates, packages and event details.",
  },
  facilitySection: {
    eyebrow: "THE DETAILS, DIRECTLY FROM THE OWNER",
    title: "Make it your own occasion.",
    description: "Facility details are being confirmed. Call or WhatsApp the owner to discuss what your event needs.",
  },
  gallerySection: {
    eyebrow: "PHOTOGRAPHS FROM USTAAD",
    title: "A glimpse of gatherings.",
    description: "Verified Ustaad banquet and event photographs will appear here once supplied.",
    photoNeeded: "Ustaad photo needed",
  },
  faqSection: {
    eyebrow: "A FEW THINGS TO ASK",
    title: "Let’s talk details.",
    description: "For event dates, packages, pricing, capacity and facilities, please call the owner.",
  },
  endcapEyebrow: "YOUR OCCASION, YOUR WAY",
  endcapDescription: "Dates, packages and pricing are handled directly with the owner by phone or WhatsApp.",
} as const;
