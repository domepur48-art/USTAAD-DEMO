export const pageSeo = {
  home: {
    title: "Ustaad Cafe Restaurant Banquets | Kushaiguda",
    description:
      "Visit Ustaad Cafe Restaurant Banquets in Weavers Colony, Kushaiguda, Secunderabad for biryani, kebabs, Indian and Chinese favourites, seafood and celebrations.",
  },
  restaurant: {
    title: "Restaurant in Kushaiguda | Ustaad Cafe",
    description:
      "Explore Ustaad Restaurant in Weavers Colony, Kushaiguda for biryani, kebabs, Indian favourites, Chinese, seafood and vegetarian dishes.",
  },
  banquets: {
    title: "Banquets & Events in Kushaiguda | Ustaad Cafe",
    description:
      "Discover Ustaad Banquets in Kushaiguda, Secunderabad for weddings, engagements, birthdays, corporate and family functions. Call the owner for dates and details.",
  },
  gallery: {
    title: "Gallery | Ustaad Cafe Kushaiguda",
    description:
      "Explore food, ambience, banquet and event photography from Ustaad Cafe Restaurant Banquets in Kushaiguda. Ustaad photos are being prepared.",
  },
  about: {
    title: "About & Reviews | Ustaad Cafe Kushaiguda",
    description:
      "Learn about Ustaad Cafe Restaurant Banquets in Weavers Colony, Kushaiguda, Secunderabad. Owner story and confirmed Google reviews to be added.",
  },
  contact: {
    title: "Contact & Directions | Ustaad Cafe Kushaiguda",
    description:
      "Find Ustaad Cafe Restaurant Banquets at 606/G2 Part, Weavers Colony, Bhavana Nagar, Kushaiguda, Secunderabad. Call or get directions.",
  },
} as const;
