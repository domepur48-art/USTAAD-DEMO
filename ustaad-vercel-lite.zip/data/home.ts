export const homeContent = {
  hero: {
    eyebrow: "WEAVERS COLONY, KUSHAIGUDA",
    title: "Two ways to gather. One house of Ustaad.",
    description:
      "A complete restaurant and one single banquet hall for the moments that matter.",
  },
  infoBar: {
    rating: "[4.x] from [N] Google reviews",
  },
  signatureEyebrow: "FROM OUR KITCHEN",
  signatureTitle: "Signature dishes",
  dishes: [
    { name: "Chicken Biryani", category: "Biryani", price: "₹[price]", photoId: "dish-biryani" },
    { name: "Seekh Kebab", category: "Kebabs", price: "₹[price]", photoId: "dish-kebab" },
    { name: "Veg Hakka Noodles", category: "Chinese", price: "₹[price]", photoId: "dish-noodles" },
    { name: "Tandoori Fish", category: "Seafood", price: "₹[price]", photoId: "dish-fish" },
  ],
  whyUs: [
    {
      title: "Biryani, kebabs and curries",
      description: "A range of familiar favourites from the kitchen.",
    },
    {
      title: "Indian and Chinese together",
      description: "Different cravings, gathered in one place.",
    },
    {
      title: "Seafood and vegetarian choices",
      description: "Options for a table with varied tastes.",
    },
    {
      title: "Restaurant and one banquet hall",
      description: "Two ways to gather, under one roof.",
    },
  ],
  restaurantFeature: {
    eyebrow: "MAKE YOURSELF AT HOME",
    title: "Good food, gathered around one table.",
    description:
      "Visit Ustaad in Weavers Colony for biryani, kebabs, Indian favourites, Chinese, seafood and vegetarian dishes.",
  },
  featureCards: {
    restaurant: {
      eyebrow: "YOUR TABLE IS READY",
      title: "Dine in.",
      link: "Visit us",
      note: "A TABLE AT USTAAD",
    },
    banquets: {
      eyebrow: "MAKE IT A MOMENT",
      title: "The single banquet hall.",
      description: "One considered space for weddings, birthdays and family functions.",
      link: "Plan your event",
    },
  },
  galleryEyebrow: "A GLIMPSE OF USTAAD",
  galleryTitle: "A place for every kind of gathering.",
  banquetEyebrow: "USTAAD BANQUETS",
  banquetTitle: "One hall. Your occasion.",
  banquetDescription:
    "Weddings, engagements, birthdays, corporate and family functions. Dates, packages and pricing are handled directly with the owner by phone or WhatsApp.",
  capacityPlaceholder: "Capacity: [number] guests",
  facilitiesPlaceholder: "Facilities: [AC, parking, stage, décor, catering]",
  reviewsTitle: "A table is better when it’s shared.",
  reviewsDescription: "Real Google review details to be added after owner confirmation.",
  contactTitle: "Visit Ustaad",
} as const;
